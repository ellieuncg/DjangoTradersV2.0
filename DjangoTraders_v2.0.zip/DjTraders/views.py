from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import DetailView, ListView, UpdateView
from django.contrib import messages
from django.utils import timezone
from .models import Customer, Product, Category, OrderDetail, Order
from .forms import CustomerForm, ProductForm

def index(request):
    """
    Landing page view for the application.
    Renders the main index template.
    """
    return render(request, 'DjTraders/index.html')

# ============================
# Customer Views
# ============================

class DjTradersCustomersView(ListView):
    """
    Display and filter customer list.
    Supports searching, filtering, and sorting of customer records.
    """
    model = Customer
    template_name = 'DjTraders/customers.html'
    context_object_name = 'customers'

    def get_queryset(self):
        """
        Build the customer queryset with applied filters and sorting.
        
        Filters:
        - Customer name (partial match)
        - Contact name (partial match)
        - City (partial match)
        - Country (exact match)
        - Starting letter of customer name
        - Status (active/inactive/archived)
        """
        queryset = Customer.objects.all()
        
        # Extract search parameters from request
        customer_query = self.request.GET.get('customer', '')
        contact_query = self.request.GET.get('contact', '')
        city_query = self.request.GET.get('city', '')
        country_query = self.request.GET.get('country', '')
        letter = self.request.GET.get('letter', '')
        status = self.request.GET.get('status', 'active')
        
        # Apply search filters
        if customer_query:
            queryset = queryset.filter(customer_name__icontains=customer_query)
        if contact_query:
            queryset = queryset.filter(contact_name__icontains=contact_query)
        if city_query:
            queryset = queryset.filter(city__icontains=city_query)
        if country_query:
            queryset = queryset.filter(country__iexact=country_query)
        if letter:
            queryset = queryset.filter(customer_name__istartswith=letter)
        
        # Apply status filter
        if status != 'all':
            queryset = queryset.filter(status=status)

        # Handle sorting
        sort_field = self.request.GET.get('sort')
        sort_direction = self.request.GET.get('direction', 'asc')
        if sort_field:
            # Map frontend field names to model fields
            field_mapping = {
                'customer': 'customer_name',
                'contact': 'contact_name',
                'city': 'city',
                'country': 'country'
            }
            sort_field = field_mapping.get(sort_field, sort_field)
            if sort_direction == 'desc':
                sort_field = f'-{sort_field}'
            return queryset.order_by(sort_field)

        return queryset.order_by('customer_name')  # default sorting

    def get_context_data(self, **kwargs):
        """
        Add additional context for the template:
        - Search query parameters
        - Status filter
        - List of available countries
        - Current letter filter
        """
        context = super().get_context_data(**kwargs)
        status = self.request.GET.get('status', 'active')
        countries = Customer.objects.values_list('country', flat=True).distinct().order_by('country')
        
        context.update({
            'customer_query': self.request.GET.get('customer', ''),
            'contact_query': self.request.GET.get('contact', ''),
            'city_query': self.request.GET.get('city', ''),
            'country_query': self.request.GET.get('country', ''),
            'status_filter': status,
            'countries': countries,
            'current_letter': self.request.GET.get('letter', '')
        })
        return context

class DjTradersCustomerDetailView(DetailView):
    """
    Display detailed customer information and order history.
    Includes sorting capabilities for order details.
    """
    model = Customer
    template_name = 'DjTraders/CustomerDetail.html'
    context_object_name = 'customer'

    def get_context_data(self, **kwargs):
        """
        Enhance context with:
        - Sorted order history
        - Product details for each order
        - Sort parameters for maintaining state
        """
        context = super().get_context_data(**kwargs)
        customer = self.get_object()
        
        # Build order details list
        order_details = []
        for order in customer.orders.all().order_by('-order_date'):
            details = {
                'order_id': order.order_id,
                'order_date': order.order_date,
                'products': [{
                    'product': detail.product,
                    'quantity': detail.quantity,
                } for detail in order.orderdetails.all()]
            }
            order_details.append(details)
        
        # Apply requested sorting
        sort_field = self.request.GET.get('sort')
        sort_direction = self.request.GET.get('direction', 'desc')
        if sort_field:
            # Sort based on different fields
            if sort_field == 'order_id':
                order_details.sort(
                    key=lambda x: x['order_id'],
                    reverse=(sort_direction == 'desc')
                )
            elif sort_field == 'order_date':
                order_details.sort(
                    key=lambda x: x['order_date'],
                    reverse=(sort_direction == 'desc')
                )
            elif sort_field == 'product':
                order_details.sort(
                    key=lambda x: x['products'][0]['product'].product_name if x['products'] else '',
                    reverse=(sort_direction == 'desc')
                )
            elif sort_field == 'quantity':
                order_details.sort(
                    key=lambda x: sum(p['quantity'] for p in x['products']),
                    reverse=(sort_direction == 'desc')
                )
        
        context.update({
            'orders': order_details,
            'sort_field': sort_field,
            'sort_direction': sort_direction
        })
        return context

class CustomerArchiveView(UpdateView):
    """
    Handle customer archival process.
    Sets archived status and timestamp.
    """
    model = Customer
    fields = []
    template_name = 'DjTraders/CustomerDetail.html'
    
    def form_valid(self, form):
        """Process the archive action and redirect."""
        customer = self.get_object()
        customer.status = 'archived'
        customer.archived_date = timezone.now()
        customer.save()
        messages.success(self.request, f'Customer {customer.customer_name} has been archived.')
        return redirect('DjTraders:CustomerDetail', pk=customer.pk)

def create_customer(request):
    """
    Handle customer creation process.
    Validates and saves new customer records.
    """
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()
            messages.success(request, 'Customer created successfully.')
            return redirect('DjTraders:CustomerDetail', pk=customer.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = CustomerForm()
    return render(request, 'DjTraders/CustomerForm.html', {'form': form})

def update_customer(request, pk):
    """
    Handle customer information updates.
    Validates and saves changes to existing customers.
    """
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Customer updated successfully.')
            request.session['customer_updated'] = True
            return redirect('DjTraders:CustomerDetail', pk=customer.pk)
    else:
        form = CustomerForm(instance=customer)
    
    return render(request, 'DjTraders/CustomerForm.html', {
        'form': form, 
        'customer': customer
    })

def update_customer_status(request, pk):
    """
    Update customer status (active/inactive/archived).
    Handles status changes and sets appropriate timestamps.
    """
    if request.method == 'POST':
        customer = get_object_or_404(Customer, pk=pk)
        new_status = request.POST.get('status')
        if new_status in ['active', 'inactive', 'archived']:
            customer.status = new_status
            if new_status == 'archived':
                customer.archived_date = timezone.now()
            customer.save()
            messages.success(request, f'Customer status updated to {new_status}.')
    return redirect('DjTraders:Customers')

# ============================
# Product Views
# ============================

class DjTradersProductsView(ListView):
    """
    Display and filter product list.
    Supports searching, filtering by category, and price range filtering.
    """
    model = Product
    template_name = 'DjTraders/products.html'
    context_object_name = 'products'

    def get_queryset(self):
        """
        Build the product queryset with applied filters.
        
        Filters:
        - Product name (partial match)
        - Category
        - Price range (min/max)
        - Status (active/inactive)
        """
        queryset = Product.objects.all()
        
        # Extract search parameters
        product_query = self.request.GET.get('product', '')
        category = self.request.GET.get('category', '')
        min_price = self.request.GET.get('min_price', '')
        max_price = self.request.GET.get('max_price', '')
        status = self.request.GET.get('status', 'active')

        # Apply filters
        if product_query:
            queryset = queryset.filter(product_name__icontains=product_query)
        if category:
            queryset = queryset.filter(category__category_id=category)
        if min_price:
            try:
                min_price = float(min_price)
                queryset = queryset.filter(price__gte=min_price)
            except ValueError:
                pass
        if max_price:
            try:
                max_price = float(max_price)
                queryset = queryset.filter(price__lte=max_price)
            except ValueError:
                pass

        # Apply status filter
        if status != 'all':
            queryset = queryset.filter(status=status)

        return queryset.order_by('product_name')

    def get_context_data(self, **kwargs):
        """
        Add additional context for the template:
        - Search query parameters
        - Price range filters
        - Category filter
        - Status filter
        """
        context = super().get_context_data(**kwargs)
        status = self.request.GET.get('status', 'active')
        categories = Category.objects.all().order_by('category_name')
        
        context.update({
            'categories': categories,
            'product_query': self.request.GET.get('product', ''),
            'min_price': self.request.GET.get('min_price', ''),
            'max_price': self.request.GET.get('max_price', ''),
            'selected_category': self.request.GET.get('category', ''),
            'status_filter': status
        })
        return context

class DjTradersProductDetailView(DetailView):
    """
    Display detailed product information and order history.
    Includes sorting capabilities for order details and summary statistics.
    """
    model = Product
    template_name = 'DjTraders/ProductDetail.html'
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        """
        Enhance context with:
        - Sorted order details
        - Summary statistics
        - Sort parameters
        """
        context = super().get_context_data(**kwargs)
        product = self.get_object()
        
        # Get sort parameters
        sort_field = self.request.GET.get('sort', 'order__order_date')
        sort_direction = self.request.GET.get('direction', 'desc')
        
        # Map frontend field names to model fields
        field_mapping = {
            'customer': 'order__customer__customer_name',
            'order_date': 'order__order_date',
            'quantity': 'quantity',
            'total': 'quantity'
        }
        
        sort_field = field_mapping.get(sort_field, sort_field)
        order_by = f"{'-' if sort_direction == 'desc' else ''}{sort_field}"
        
        # Query and sort order details
        order_details = OrderDetail.objects.filter(product=product)
        
        # Handle total-based sorting
        if sort_field == 'quantity' and 'total' in self.request.GET.get('sort', ''):
            order_details = sorted(
                order_details,
                key=lambda x: x.quantity * x.product.price,
                reverse=(sort_direction == 'desc')
            )
        else:
            order_details = order_details.order_by(order_by)

        # Format details for display
        formatted_details = [{
            'order': detail.order,
            'quantity': detail.quantity,
            'unit_price': detail.product.price,
            'total': detail.product.price * detail.quantity,
        } for detail in order_details]
        
        # Add context
        context.update({
            'order_details': formatted_details,
            'sort_field': self.request.GET.get('sort', 'order_date'),
            'sort_direction': sort_direction,
            'total_orders': len(formatted_details),
            'total_units_sold': sum(detail['quantity'] for detail in formatted_details),
            'total_revenue': sum(detail['total'] for detail in formatted_details)
        })
        
        return context

def create_product(request):
    """
    Handle product creation process.
    Validates and saves new product records.
    """
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save()
            messages.success(request, 'Product created successfully.')
            return redirect('DjTraders:ProductDetail', pk=product.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = ProductForm()
    return render(request, 'DjTraders/ProductForm.html', {'form': form})

def update_product(request, pk):
    """
    Handle product information updates.
    Validates and saves changes to existing products.
    """
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            product = form.save()
            messages.success(request, 'Product updated successfully.')
            return redirect('DjTraders:ProductDetail', pk=product.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = ProductForm(instance=product)
    return render(request, 'DjTraders/ProductForm.html', {
        'form': form,
        'product': product
    })

def update_product_status(request, pk):
    """
    Update product status (active/inactive/archived).
    
    Args:
        request: HTTP request object
        pk: Product primary key
    
    Updates product status and handles any related timestamps.
    Redirects back to product list with success message.
    """
    if request.method == 'POST':
        product = get_object_or_404(Product, pk=pk)
        new_status = request.POST.get('status')
        if new_status in ['active', 'inactive', 'archived']:
            product.status = new_status
            if new_status == 'archived':
                product.archived_date = timezone.now()
            product.save()
            messages.success(request, f'Product status updated to {new_status}.')
    return redirect('DjTraders:Products')
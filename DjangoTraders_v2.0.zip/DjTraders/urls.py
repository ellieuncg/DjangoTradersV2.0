from django.urls import path
from . import views

# Application namespace for URL reversing
app_name = 'DjTraders'

urlpatterns = [
    # Main application views
    path('', 
         views.index, 
         name='Index'),
    
    # Customer Management URLs
    # -----------------------
    # List and search customers
    path('customers/', 
         views.DjTradersCustomersView.as_view(), 
         name='Customers'),
    
    # View individual customer details
    path('customers/<int:pk>/', 
         views.DjTradersCustomerDetailView.as_view(), 
         name='CustomerDetail'),
    
    # Create new customer record
    path('customers/create/', 
         views.create_customer, 
         name='CustomerCreate'),
    
    # Update existing customer information
    path('customers/<int:pk>/update/', 
         views.update_customer, 
         name='CustomerUpdate'),
    
    # Update customer status (active/inactive)
    path('customers/<int:pk>/status/', 
         views.update_customer_status, 
         name='CustomerStatus'),
    
    # Archive customer record
    path('customers/<int:pk>/archive/', 
         views.CustomerArchiveView.as_view(), 
         name='CustomerArchive'),
    
    # Product Management URLs
    # ----------------------
    # List and search products
    path('products/', 
         views.DjTradersProductsView.as_view(), 
         name='Products'),
    
    # View individual product details
    path('products/<int:pk>/', 
         views.DjTradersProductDetailView.as_view(), 
         name='ProductDetail'),
    
    # Create new product record
    path('products/create/', 
         views.create_product, 
         name='ProductCreate'),
    
    # Update existing product information
    path('products/<int:pk>/update/', 
         views.update_product, 
         name='ProductUpdate'),
    
    # Update product status (active/inactive)
    path('products/<int:pk>/status/', 
         views.update_product_status, 
         name='ProductStatus'),
]